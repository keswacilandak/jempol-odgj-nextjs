
export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>👋 Selamat datang di JEMPOL-ODGJ</h1>
      <p>Website pemantauan ODGJ berat secara mandiri.</p>
    </div>
  );
}
