# JEMPOL-ODGJ (Next.js MVP)
Frontend website pemantauan ODGJ Berat berbasis Next.js

## Struktur
- pages/: Halaman Login, Dashboard, Form
- components/: Komponen UI terpisah
- api/: (opsional) API dummy jika diperlukan

## Deploy
1. Buka https://vercel.com
2. Klik "Add New Project" → Upload folder ini
3. Next.js akan otomatis dikenali dan dideploy
